
package util;

import dto.UserDto;

public class Cookie {
    
     public static UserDto selectedUser;
}
